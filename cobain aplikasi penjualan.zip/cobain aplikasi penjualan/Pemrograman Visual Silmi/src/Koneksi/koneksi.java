/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Koneksi;
import java.sql.*;
/**
 *
 * @author sil
 */
public class koneksi {
    private Connection koneksi;
  public Connection connect(){
      try{
          Class.forName("com.mysql.jdbc.Driver");
          System.out.println("berhasil konek");
      }
          catch (ClassNotFoundException ex) {
          System.out.println("Gagal koneksi"+ex);
          }
          String url = "jdbc:mysql://localhost/penjualan";
      try{
            koneksi = DriverManager.getConnection(url,"root", "");
            System.out.println("berhasil koneksi database");
    }
        catch (SQLException ex) {
        System.out.println("gagal koneksi database"+ex);
        }
        return koneksi;
      }
}

